tanGraph = zeros(30,4);
sinGraph = zeros(30,4);
cosGraph = zeros(30,4);
for n = 1:30
    tanGraph(n) = tan(n);
    sinGraph(n) = sin(n);
    cosGraph(n) = cos(n);
end